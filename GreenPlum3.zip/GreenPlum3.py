from PyQt5 import uic, QtCore, QtGui, QtWidgets
from PyQt5.QtGui import QIcon
from openpyxl import load_workbook
import pyqtgraph as pg
import sys  # We need sys so that we can pass argv to QApplication
import numpy as np
from statsmodels.tsa.arima_model import ARIMA
from pandas import read_csv


class MainWindow(QtWidgets.QMainWindow):

    def __init__(self, *args, **kwargs):
        super(MainWindow, self).__init__(*args, **kwargs)
        # Load the UI Page
        uic.loadUi('main.ui', self)
        self.setWindowTitle("GreenPlum3")
        self.setWindowIcon(QIcon("MIREA_logo.png"))
        self.filename = 'pred.xlsx'
        self.pushButton.clicked.connect(self.pushButton_clicked)
        self.UpdateLB()
        self.listWidget1.itemActivated.connect(self.printItemText)
        self.Index = 1
        self.graphWidget.setBackground('w')
        self.graphWidget.setLabel('left', 'Прогноз времени выполнения запросов', color='red', size=30)
        self.graphWidget.setLabel('bottom', 'Дата', color='red', size=30)
        self.graphWidget.showGrid(x=True, y=True)
        # Set Range
        self.graphWidget.setXRange(0, 10, padding=0)
        self.graphWidget.setYRange(20, 55, padding=0)
        pen = pg.mkPen(color=(255, 0, 0))
        self.ydata = np.array([0])
        self.xdata = np.array([0])
        pname = ''
        self.data_line = self.graphWidget.plot(self.xdata, self.ydata, name=pname, pen=pen, symbol='+', symbolSize=10,
                                               symbolBrush=('b'))
        pen = pg.mkPen(color=(0, 255, 0))
        self.fdata_line = self.graphWidget.plot(self.xdata, self.ydata, name=pname, pen=pen, symbol='+', symbolSize=10,
                                                symbolBrush=('g'))
        self.graphWidget.enableAutoRange()
        self.graphWidget.setAutoVisible()
        self.zdata = np.array([0])

    def plot(self, xdata, ydata, pname):
        self.data_line.setData(xdata, ydata)

    def fplot(self, xdata, ydata, pname):
        self.fdata_line.setData(xdata, ydata)

    def printItemText(self, item):
        """These two are equivalent"""
        Index = self.listWidget1.currentRow()
        self.UpdatePlot(Index)

    def UpdateLB(self):
        wb = load_workbook(self.filename)
        sheet = wb['Sheet1']
        lb = [];
        for i in range(0, 100):
            str1 = ''
            for j in range(1, 7):
                str1 = str1 + str(sheet.cell(row=2 + i, column=j).value) + ' '
                # print(str1)
            lb.append(str1)
            self.listWidget1.insertItem(i, str1)

    def UpdatePlot(self, Index):
        kol_dney = 30;
        # kol_dney = self.spinBox_5.value()
        wb = load_workbook(self.filename)
        sheet = wb['Sheet1']
        xdata = np.arange(1, kol_dney + 1)
        ydata = np.arange(1, kol_dney + 1)
        for i in range(0, kol_dney):
            ydata[i] = int(sheet.cell(row=2 + i, column=6).value)
        self.plot(xdata, ydata, 'данные 1')
        self.ydata = ydata
        self.xdata = xdata
        self.fdata_line.setData([0], [0])
        self.Index = Index

    def pushButton_clicked(self):
        self.UpdatePlot(self.Index)
        kol_dney = self.spinBox_5.value()
        kol_dney = 30
        # series = read_csv('data.csv', header=0, parse_dates=[0], index_col=0, squeeze=True)
        series = read_csv('data.csv')
        ydata = self.ydata
        for i in range(0, kol_dney):  # zzz
            series.values[i] = ydata[i]
        k1 = 4
        k2 = 1
        k3 = 0
        # if kol_dney > 25:
        #     k1 = self.spinBox_3.value()
        #     k2 = self.spinBox.value()
        #     k3 = self.spinBox_2.value()
        print(series)
        model = ARIMA(series, order=(k1, k2, k3))
        print(series)
        model_fit = model.fit(disp=0)  # (trend='nc', disp=False)
        # print(model_fit.summary())
        text = str(model_fit.summary())
        # self.tex
        self.textEdit.append(text)
        s_prognoz = self.spinBox_4.value()
        forecast = model_fit.forecast(steps=s_prognoz)[0]
        fxdata = np.arange(len(ydata) + 1, len(ydata) + len(forecast) + 1)
        fydata = np.arange(len(ydata) + 1, len(ydata) + len(forecast) + 1)

        for i in range(0, len(fxdata)):
            fydata[i] = int(forecast[i])
        ydata = np.append(ydata, forecast)
        for i in range(1, len(ydata)):
            ydata[i] = int(ydata[i])
        xdata = np.arange(1, len(ydata) + 1)
        self.plot(xdata, ydata, 'Данные 1')
        self.fplot(fxdata, fydata, 'Данные 1')

def main():
    app = QtWidgets.QApplication(sys.argv)
    main = MainWindow()
    main.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
