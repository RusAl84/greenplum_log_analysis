import sys
import pandas as pd
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import (QApplication,QFileDialog, QMainWindow, QAction, QTableWidget, QTableWidgetItem)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("GreenPlum2")
        self.setWindowIcon(QIcon("./MIREA_logo.png"))
        self.resize(1280, 720)

        #list of data var
        self.openedFileName = ""
        # Ui-Widgets of MainWindow

        OpenButtonAction = QAction(QIcon("../open.png"), "&Открыть файл...", self)
        OpenButtonAction.triggered.connect(self.onOpenButtonActionClick)

        menu = self.menuBar()

        file_menu = menu.addMenu("&Меню")
        file_menu.addAction(OpenButtonAction)

        # Create an Main table view
        self.table = QTableWidget()

        self.setCentralWidget(self.table)


    def onOpenButtonActionClick(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        self.openedFileName, _ = QFileDialog.getOpenFileName(self, "Открыть файл...", "",
                                                             "All Files (*);;"
                                                             "Comma-Separated Values (*.csv)", options=options)
        if self.openedFileName:
            self.loadDataOnTable()
    def loadDataOnTable(self):
        df = pd.read_excel(self.openedFileName)
        if df.size == 0:
            return
        self.table.setRowCount(df.shape[0])
        self.table.setColumnCount(df.shape[1])
        self.table.setHorizontalHeaderLabels(df.columns)

        #returns pandas array object
        for row in df.iterrows():
            values = row[1]
            for col_index, value in enumerate(values):
                if isinstance(value, (float)):
                    value = '{0:0,.0f}'.format(value)
                tableItem = QTableWidgetItem(str(value))
                self.table.setItem(row[0], col_index, tableItem)

        self.table.setColumnWidth(2, 300)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    app.exec()
